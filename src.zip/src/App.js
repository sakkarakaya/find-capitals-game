import './App.css';
import MyMapComponent from "./pages/Mapchart";
import ContainedButtons from "./components/Buttons"

function App() {
  return (
    <div className="App">
      <ContainedButtons />
      <MyMapComponent />
    </div>
  );
}

export default App;
