import React, { useState } from 'react'
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import CapitalCities from '../capitalCities.json'

let score = 0
let kilometersLeft = 1500

const useStyles = makeStyles((theme) => ({
  root: {
    '& > *': {
      margin: theme.spacing(1),
      display: "flex",
      alignItems: "center",
      justifyContent: "center",

    }
  },
}));

export default function ContainedButtons() {
  const [cityIndex, setCityIndex] = useState(0)
  const classes = useStyles();

  const handleNext = () => {
    //console.log(CapitalCities[i].capitalCity)
    setCityIndex(cityIndex + 1)
  }

  return (
    <div className={classes.root}>
      <Button variant="contained">{score} cities placed</Button>
      <Button variant="contained">{kilometersLeft} kilometers left</Button>

      {cityIndex < 9 ?
        <p>Select the Location of {CapitalCities[cityIndex].capitalCity}</p> :
        <p>Your score: </p>}

      <Button onClick={handleNext} variant="contained">next city</Button>
    </div>
  );
}